MIRROR — DO NOT EDIT

Source: Docs/Project/current-milestone.md
Context: 852304d8a668d6ee2b04547aaec751be6b462c53
Snapshot timestamp: 2026-11-19T19:11:24Z

# Current Development Milestone

## Purpose

Define the current Scenario One milestone, its completion boundary and the work that remains. Verified implementation detail belongs in `Docs/Project/unity-project-overview.md`; accepted product decisions belong in `Docs/Project/decision-log.md`; temporary ownership and execution locks belong in `Docs/Project/coordination/active-tasks.md`.

**Last reconciled:** 2026-11-17 — the seventeen Round 1 and Round 2 Compact30 owner directions are recorded in D-085 as accepted **intent** only, with world bytes still unsigned (D-085 appended in a controlled canonical publication branch). Historical Enlarged80 qualification remains dated evidence, not Compact runtime proof.

## Milestone

**Scenario One — Complete-Loop Three-Species Demo Readiness**

The first external invited closed beta targets the **new Compact30, no-internal-rack complete Scenario One** (D-083 clarifies D-060), not the previous Enlarged80 five-rack forest and not a first-intervention pilot. Before that demo, Sitka spruce, Oak and Beech must be represented to comparable modelling depth (D-059), and the player must be able to assess the stand, plan and execute management, review consequences, make second and later interventions, repeat the management cycle and reach understandable scenario completion.

No qualified Compact30 external-demo candidate exists yet. No Windows build is authorised before the user personally playtests the **exact Compact30 Scenario One Editor candidate** and separately explicitly authorises a Windows build.

## Active first-beta target — Compact30 (D-083 owner-ratified product scope)

**First personal Editor-test and first invited closed-beta target:** a **new, independent 30×30 m (0.09 ha) initially all-Sitka woodland**, no internal extraction racks, ~12×10 m **pre-existing** H1 southern arrival/parking/collection clearing, one winding *pedestrian-only* woodland footpath, and a first genuine player-led planting group of **2 sessile Oak + 2 European Beech**. The fourteen source-screened Sitka tree omissions inside H1 represent **pre-world layout**, never player felling, timber revenue, or annual intervention. The original 189 Sitka is a pre-layout source model; 175 is conditional arithmetic, **not a signed or runtime-qualified final tree count**. Actual G1 coordinates, four plant admissibility, post-H1 light, path core/collision and guard meshes remain **unsigned and not Unity verified**. D-085 now fixes the owner-directed target of a smooth winding ~1.2 m walkable core with ≤0.20 m visual-only verge and compact guards distinguishable by form; exact spline, control points, terminal geometry and guard meshes are still unauthored, and the existing O1 failed-guard 0.141 m visual intrusion must be eliminated by the new visuals rather than accepted. Do not assume route PASS.

**Full-loop commitment remains:** Sitka/Oak/Beech comparable species depth (D-059), genuine stock and Work Plan approval, actual annual execution and causal ecology, browsing/protection, cost and time, later substantive interventions/no-work decisions, annual review/history (S1-C), repeated adaptive decisions (S1-D), and meaningful completion (D-060). The new Compact world **does not require** historical five-rack planning/rack-first marking/MFM lessons inside its no-rack boundary; D-064/D-065/D-071/D-072 continue to govern **historical Enlarged80 only**.

**Implementation gates, not accepted features:** D-084 now **accepts owner product intent** for Compact shelter Option A (target 1.2m walking core/≤0.20m visual-only verge), teaching T1, finite €12,000 F-A, substantive adaptive completion M-A, Approved-order cancellation/reapproval W-A and optional C6/C10 deferral. This does **not** sign actual G1/world/guard geometry or exact M-A evidence threshold. Parent and initial-planting four-file specs remain **DRAFT**; #614/#616/#617 passed targeted document-quality checks only. #576 world manifest candidate and #583/#622 source geometry are unsigned/not native. CG-TRIG/ISO-58, precise financing/completion/admission contracts, direct-approved-order edit guards and scene/identity/Stand Map/profile routing still require reviewed specs, implementation and verified tests. The immutable signed three-profile **save policy** is not proof that the Compact profile has been implemented, activated, run or safe against v1–v24 older saves. D-032 full art source/licence/binary policy remains OPEN, and the separated visual-art spec is DRAFT. Final artwork may develop one-at-a-time in parallel with **approved** Linux gameplay using stage-honest existing first-party assets and built-in primitive stand-ins; correct geometry is not optional art polish. No #611 Windows material experiment is a dependency of the Linux core loop.

**Owner-directed Compact30 content and presentation (D-085) — intent accepted 2026-11-17, nothing signed:** the owner personally answered all seventeen Round 1 and Round 2 choices, and they now govern the intended Compact30 world **as directions only**. **World basis:** flat terrain `y = 0` with no hydrology; the pinned real-source 36-cell ecology constructor, selectors and seed on the half-open `[−15,+15)` edge with no dormant `Reference` site profile; the exact 175-row roster `dac06a3b…` adopted verbatim (eight buffer stems, nineteen former rack-labelled stems); initial tree state from the pinned fresh-source constructor; the owner personally is the signer. **Presentation:** a separate Compact scene/hierarchy under D-032 first-party rights; deterministic tree-ID-driven Sitka visuals from a pinned stage-compatible asset set; a smooth winding ~1.2 m pedestrian core with ≤0.20 m visual-only verge ending naturally almost at the north edge; a flat, soft-edged, stumpless ~12×10 m H1 with no parked trucks or equipment; compact guards distinguishable by form; player start inside H1 facing the path with 3.5 m interaction and 8 m marking reach. **Gameplay:** four designated G1 sites only (2 sessile Oak + 2 European Beech) at zero planar tolerance; an all-unmarked stand where the player personally selects and retains three crop trees; one versioned whole-world content manifest with one whole-world digest. **Still unsigned and gated:** every actual byte, coordinate, spline, mesh, seed-value record and asset digest; the world stands at **SIGNED 0 / CANDIDATE 36 / BLOCKED 52** with **36 ecology cells BLOCKED** at the last published #672 audit; [#676](https://github.com/jermur788/CCF/issues/676) world-manifest authoring is in flight and its status is **not** preclaimed here; [#677](https://github.com/jermur788/CCF/issues/677) save-policy signer remains **BLOCKED**; three Compact spec families remain **DRAFT** with unchecked requirements; CG-TRIG/ISO-58 **BLOCKED** and #652 live deployment **HELD**. The precise minimal acted-on stem count (OD-16, M-A-SCOPE) is still **owner-DEFERRED** and D-084's substantive-work completion contract is unchanged; three retained crop trees are not a three-Fell quota. No runtime, rendered or player evidence exists for any of these directions.

**Historical continuity:** Existing Enlarged80 with its **five-rack layout**, Rack V2/MFM/Stand Map, Legacy40, historical exact saves and frozen Reference Future v1 remain intact and separately regression-tested. Nothing in D-083 retrospectively un-verifies their earlier feature evidence or automatically integrates the new Compact world. All Scenario One production development/Unity qualification is on **Linux**, apart from the explicitly isolated #611 temporary Windows scratch material-look exception. No Windows Player build before the owner personally tests the exact qualified Compact Editor candidate and explicitly permits a build.

## Current programme state

### Rack V2 / D-064 — feature-scope verified

Rack V2 is the authoritative Enlarged80 access-planning workflow. Rack geometry is planned on the Stand Map; confirmed entrances are physically marked in the 3D forest; Legacy40 and frozen Reference Future v1 compatibility remain mandatory.

The Rack V2 implementation, persistence, field marking, functional end-to-end and rendered qualification programme is complete for feature scope. The exact integrated Rack candidate `60fd9025e0205e7e8b24203295dd606ffa4a8061` is retained in the current published Scenario One integration ancestry.

The independent G4 review is published at `Docs/Handoffs/RACK-V2-14/FINAL-CONFORMANCE-REVIEW-20261030.md` and returned:

`OBJECTIVE 1 RACK PLANNING & FIELD MARKING V2 QUALIFIED — READY FOR USER TEST`

That review disposes AC-1…AC-20 and D-064 OPEN-1…OPEN-3 as PASS from the accepted Rack evidence chain. Five rendered polish observations remain non-blocking for the later personal playtest. Rack V2 feature verification is distinct from whole-Scenario-One Tier-3 verification and from user acceptance.

The D-065 production gate requiring Rack V2 persistence/integration has therefore been satisfied. This does not bypass later MFM prerequisites or live ownership/Unity serialization.

### Scenario One access-network scope — D-071 current parallel layout retained

**Accepted latest product choice (5 November 2026):** Scenario One uses the existing **headland-entry, five parallel extraction racks** (illustration “Option A”). The user's earlier spine/diagonal preference (D-067–D-069) is **superseded for Scenario One** and remains independently reviewed historical design research only. No new northern spine, herringbone 3+2, single-family spine entry, player-built northern extension or speculative access-construction gameplay is a Scenario One external-demo requirement. More complex layouts can be considered as **future separate scenarios**, under their own acceptance and specifications.

The accepted Rack V2 map planning, field-marked orange first rack-removal-tree entrances, five-rack lesson, conditional 16–20 m site guidance, Work Plan commitment and MFM V1 parallel coverage remain unchanged. No new two-family MFM model, rack clearance-policy or northern save-identity change is authorised. **Do not treat the visual illustration “Option A” as the unrelated research nickname “MFM Option A” for an unapproved two-family algorithm.** The prior spec `specs/scenario-one-access-spine-route-consistency-v1/` is historical / **SUPERSEDED FOR SCENARIO ONE**; its approved research quality is not an approved product implementation.

**Separate D-070:** hidden Forestry Workbench source-level new-game retirement is still an accepted cleanup goal independent of whether a northern spine is built. #284 candidate is source-reviewed but not integrated or Unity-qualified; #287 is WAITING for explicit release of the user's personal playtest and a safe exclusive Unity lease. Keep all old-save/Legacy40/Reference Future protections and the separate Windows build gate. No new spine implementation tasks should enter the pre-demo sequence.

### D-072 — align full Stand Map to existing V2 headland before teaching diagram

**LATEST D-072 REVIEW VERDICT — 2026-11-06:** Manager #200 [ruled NEEDS CHANGES on both independent review streams](../Handoffs/ScenarioOne-Overnight-Playtest-Readiness-20261106/MANAGER-D072-STREAM-A-B-REVIEW-RULING-20261106.md). Stream A [#307](https://github.com/jermur788/CCF/issues/307) source review found no new diagram C# defect (B-1 old-world guard and M-1/M-2/M-3 source PASS, headland source checks PASS), but #306 five-rack checker lacks standalone diagram file pins, weakened-checker integrity tests and exact file inventory (F-1/F-2/F-3). **#308 verification-only repair** Medium–High next in the conditionally owned feature worktree, then NEW independent combined review and Manager verdict; #306 author's orchestrator-only process deviation and unsupported pre-edit clean claim recorded (never backdated). Stream B [#305](https://github.com/jermur788/CCF/issues/305) independent review reproduced known CTA checker tallies but found **50 new false greens** in ordinary broken C# variants; **#309 verification-only repair** High next in separate verifier worktree, new independent review and Manager verdict. Both next claims **READY FOR ACTUAL LOCAL PREFLIGHT / NOT RUNNING**, actual branch/HEAD/owner/clean evidence required. Published #307 original review is authoritative; unpushed duplicate docs branch is not a second review and must be preserved/reconciled. **#287 Workbench Unity WAITING; no machine lease, integrated candidate, personal playtest acceptance, Windows or Player build.** Earlier source gate summaries below are historical for their dates.



**Current D-072 Stage B gate (Manager #200, 6 November 2026):** #296 bounded source repair is handed off but not independently accepted; its five-rack checker passed 131/131 in a clean **pre-#303** clone. #303 inherited Stand Map HeadlandOffline checker source repair is **HANDED-OFF/CLOSED SOURCE TASK** (worker-reported 39 source + 92 C# offline PASS and 20 negative mutations; not independent/Unity PASS). On the combined source after authorised #303 verification files, the existing #296 checker **FAILS 2/131** on its old inventory allowlist. The Manager published [a strict #306 verifier-only reconciliation task](../Handoffs/ScenarioOne-Overnight-Playtest-Readiness-20261106/MANAGER-D072-303-HANDOFF-AND-FIVE-RACK-INVENTORY-RECONCILIATION-20261106.md): pin exact #303 two scripts and historical report, retain original #296 tests and negative mutations, reject any unexpected sources, and rerun **both** suites on the same candidate. **#306 ready for actual conditional single-writer T3 Code preflight, not running**; then separately reviewed combined #296/#303/#306 source and Manager verdict before #287 Unity. #304/#305 CTA checker verification is a separate concurrent lane. **No new Unity lease, integrated candidate or Windows/Player build.** Older D-072 source-status paragraphs below are historically accurate for their dates but not current programme gate.



**Confirmed user Option B on 6 November 2026:** the full Stand Map must visibly represent the **already-existing** western headland and southern feeder that the 3D Scenario One Enlarged80 Rack V2 world contains; **then** complete the faithful five-parallel-rack Objective 1 teaching diagram. This supersedes the interim “defer T3” product decision, **without** authorising a new road, different rack layout, altered 3D geometry, saved path, minimap change, tree clearance or management approval. D-071's existing five-parallel-rack configuration remains controlling. [Decision D-072](decision-log.md), [approved bounded four-file spec](../../specs/scenario-one-stand-map-headland-teaching-alignment-v1/spec.md) and [binding Manager map-first packet](../Handoffs/ScenarioOne-Overnight-Playtest-Readiness-20261106/D072-STAND-MAP-HEADLAND-REPAIR-PACKET.md).

**Current source status (Manager #200 reconciled 6 November 2026):** [#295 Objective 1 cue and safe-rack-prompt source](https://github.com/jermur788/CCF/issues/295) remains IMPLEMENTED / INDEPENDENTLY SOURCE-REVIEWED / MANAGER APPROVED SOURCE ONLY. D-072 independent spec reviews #298 accepted after blocker repairs. [#297 Stand Map existing-headland source](https://github.com/jermur788/CCF/blob/main/Docs/Handoffs/ScenarioOne-Overnight-Playtest-Readiness-20261106/MANAGER-D072-MAP-SOURCE-APPROVAL-AND-DIAGRAM-RELEASE-20261106.md) now also **IMPLEMENTED / INDEPENDENTLY SOURCE-REVIEWED / MANAGER APPROVED SOURCE ONLY**, with 122 focused source/offline assertions and 176 shared Stand Map checks passing on the independent rerun plus two effective source mutations; five nonblocking notes carried to Unity. Actual independent reviewer ran LOW effort despite HIGH requested: Manager explicitly accepted the evidence, not the claimed setting, and requires actual future effort reporting. #297 source writer released; [#296 five-parallel-rack teaching diagram](https://github.com/jermur788/CCF/blob/main/Docs/Handoffs/ScenarioOne-Overnight-Playtest-Readiness-20261106/D072-T3-FIVE-RACK-TEACHING-DIAGRAM-IMPLEMENTATION-PACKET.md) is **READY FOR ACTUAL LOCAL SOURCE PREFLIGHT / NOT RUNNING**, conditionally allocated the original feature branch/isolated worktree only after clean/HEAD/owner/disk checks; earlier authentic five-entrance reference remains evidence, no diagram implementation yet. DeepSeek chooses actual available model/effort per job. A **new separate independent source-review claim** and Manager gate follow #296 before [#287 Workbench Unity](https://github.com/jermur788/CCF/issues/287) with fresh exclusive lock. #294 overnight chain at #296, not playtest ready. Preserve Full-only map overlay, old Paths/Mini unchanged, physical rack geometry, Legacy40 and frozen Reference Future v1.

**Qualification remaining:** 1280×720 / 1920×1080 colour and grayscale map+diagram, actual native input and safe destructive focus, Stand Map versus 3D route correspondence, **minimap and Legacy40/frozen Reference Future v1 unchanged**, save/load and Work Plan/MFM boundaries, protected tests. Historical feedback checker exit 2 had a separate non-weakening browser-source repair under [#299](https://github.com/jermur788/CCF/issues/299) / [PR #300](https://github.com/jermur788/CCF/pull/300), **SOURCE HANDOFF ONLY**; independent local Python and real .NET SnapFar qualification under [#301](https://github.com/jermur788/CCF/issues/301) and final integrated exact-candidate recheck remain **NOT PASSED**. Do not treat the original failure as resolved until these gates pass. #287 user occupancy release is already recorded, but actual machine/process/storage checks and a fresh exclusive Unity lease are still mandatory when its sequence is reached. No Windows/Player build before the user's future personal playtest of an exact candidate and separate explicit authorisation.

### Sitka/Oak/Beech parity P0 — core slices accepted; final integrated parity still pending

The accepted parity programme now includes PARITY-03 through PARITY-08 on the published Scenario One integration lineage. Comparable modelling depth does not imply equal empirical precision; the accepted evidence classes/limitations remain binding and unsupported precision must not be invented.

Current status:

- **PARITY-03 mixed-density parity:** accepted/qualified. Q10 remains non-blocking evidence-strengthening work and does not invalidate the accepted result.
- **PARITY-04 adult Oak/Beech parity:** accepted/qualified.
- **PARITY-05 early-life growth/browsing parity:** accepted/integrated, including the authorised browse-anchor reconciliation.
- **PARITY-06 timber/economy parity:** accepted/qualified/integrated.
- **PARITY-07 rendered species parity:** accepted/qualified/integrated.
- **PARITY-08 persistence/back-compatibility:** independently approved and integrated; exact merge `7d2049e862df5c9311748167423b981e713d1fa9`, docs/integration successor `8fa83bff22ea1b4943689bee1074eed8eae65d2f`.
- **PARITY-09 final integrated parity qualification:** not yet released. Its authoritative start gate requires MFM-10 `SPECIES GUARD QUALIFIED`; after that token exists, PARITY-09 must be freshly repinned to the then-current integration candidate before local qualification.

The existing model-0 completion diagnostic mismatch was reproduced on the accepted baseline and remains pre-existing D-047/D-048 verification debt rather than a PARITY-08 regression. Protected pure-Sitka anchors remain unchanged where required.

### S1-C — review/history for repeated intervention — late-stage qualification

S1-C is pre-demo scope under D-060 and is substantially implemented/integrated.

Accepted/integrated programme state includes T-01 through T-06: read-only management-history query, Annual Review year browsing, intervention drill-down/money honesty, provenance labelling, objective/progression history and prior-treatment guidance.

A browser audit found that **T-07 — S1-D data contract and stability checks** had not received its own durable qualification and must not be inferred complete merely from later feature success. The existing history helper already documents important identity semantics, including stable ID pass-through and `harvestJobId` as a resolution-year grouping label rather than unique job identity, but T-07 also requires explicit offline stability assertions on current and genuine old-save fixtures.

T-07 is therefore released as bounded **offline verification** under claim #187. It requires no Unity by default and may run in parallel with the current #151 Unity task. It owns verification/docs only unless a separate Manager disposition is required.

**T-08 — final S1-C feature qualification** is browser-prepared but not released. It waits for T-07 Manager acceptance and a free serialized Unity lane. Its final Tier-2 matrix must include multi-year browsing, intervention drill-down, grouped-harvest money honesty, no-work year, provenance classes, prior-treatment guidance, objective history, current save/load, a genuine v20 old-save path, read-only history semantics and rendered 1280×720 / 1920×1080 evidence.

Grouped harvest money remains authoritative at the annual settlement level; successful non-harvest work may show its own recorded contractor/material/owner-time values. Historical browsing must remain read-only with respect to current game state.

### S1-D — repeated interventions — final feature gates underway

S1-D is pre-demo scope under D-060 and is substantially implemented.

Accepted/integrated state includes:

- T-01 repeated-intervention baseline re-verification;
- T-02 advisory cycle/readiness state;
- T-03 teaching-footprint-cap decoupling;
- T-04P durable one-way historical teaching-completion persistence;
- T-04 guide monotonicity;
- T-06 management-event ID integrity/save hardening, including repaired verification fixtures and Unity qualification/integration;
- T-07 broad persisted cycle-state expansion remains intentionally cancelled for V1 by D-066.

**T-05 — previous vs proposed management presentation** is the remaining active implementation/qualification gate. Its exact pushed head `4ddf4aa535d4ec5267be46d2635679411d595e0f` is independently approved offline/static; its Unity qualification is currently running. No Manager runtime/rendered verdict or integration may be inferred until the completed Unity handoff is inspected.

D-066's accepted persistence contract is one bounded v24 boolean-like historical teaching-completion latch written only at the genuine first guided sample/review completion boundary, default false on old saves, one-way false→true, and excluded from protected/world identity hashes. The stale rule that “S1-D adds no schema field” is superseded by that accepted decision. No broader per-cycle/guide/readiness persistence is authorised.

**T-08 — multi-cycle integrated witness** is browser-prepared but not released. It waits primarily for T-05 Unity qualification, final Manager approval and integration. It must prove at least three real management cycles, idle year(s), stale/carried Pending work, save/load, exact Annual Review/history navigation, completion, continued management after completion, D-057 solvent/economy viability and protected regressions.

**T-09 — independent spec-conformance review** follows T-08 PASS and is also browser-prepared. It must use a reviewer independent from the T-08 executor and verify the complete accepted S1-D contract, including D-066.

### Multi-Scale Forestry Management V1 / D-065 — core implemented; final sequence prepared

Multi-Scale Forestry Management V1 is required before beginner/external Scenario One testing. Its approved rule remains: demonstrated sample treatment may be applied to comparable rack-served areas; candidates/proposals do not replace player judgement; proposals are not Fell marks; prescription approval does not itself commit work; ordinary Work Plan approval remains the commitment gate.

The Rack persistence/integration production gate in D-065 is satisfied. MFM-02 through the core deterministic pipeline are present, and MFM-03 static calibration has been independently reproduced/accepted as a **GAMEPLAY CALIBRATION** input. MFM-03's independent-review caveats—especially unmeasured live post-Lesson-5/cross-year drift—remain binding and are explicitly carried into MFM-11 rather than treated as proven away.

Current final MFM sequence:

- **MFM-08 — Stand Map / 3D treatment review UX:** exact production candidate `d55ec86a3f0bf13820f2080197b6b0f43d832e06`; browser/static verdict `APPROVED — STATIC/OFFLINE PHASE ONLY; UNITY TIER-2 STILL REQUIRED`. Its Unity gate waits behind #151.
- **MFM-09 — teaching / Work Plan integration:** browser packet prepared, not released. Requires accepted/integrated #151 + #156 and fresh exact-lineage repin.
- **MFM-10 — species-parity integration guard:** browser packet prepared, not released. Requires MFM-09. Exact success token `SPECIES GUARD QUALIFIED`; Oak/Beech must not silently receive Sitka-only quantitative treatment.
- **MFM-11 — calibration impact qualification:** browser packet prepared, not released. Requires MFM-10. It must compare sample-only, representative-prescription and plausible manual paths, resolve the MFM-03 live/cross-year residual and return `MULTI-SCALE CALIBRATION QUALIFIED` or `BLOCKED — CALIBRATION IMPACT`, followed by independent review.
- **MFM-12 — integrated MFM qualification:** browser packet prepared, not released. It requires the complete approved requirements matrix, integrated Unity/rendered/save/compatibility/complete-loop evidence and independent architecture/spec review. Exact success verdict: `MULTI-SCALE FORESTRY MANAGEMENT V1 — INTEGRATED / READY FOR USER PLAYTEST`.

No browser-prepared packet authorises local implementation before its stated dependency/ownership gates are true.

## Pre-demo sequence

The sequence is dependency-driven rather than a licence to bypass live ownership. Current intent is:

1. Finish #151 S1-D T-05 Unity qualification; browser/Manager immediately performs final runtime/rendered review and safe integration only if APPROVED.
2. In parallel, complete S1-C T-07 offline contract/stability verification and Manager review.
3. After #151 releases the Unity lane, run #156 MFM-08 Tier-2 and final Manager review/integration.
4. Complete S1-C T-08 when T-07 is accepted and Unity is available.
5. Complete S1-D T-08 multi-cycle witness after T-05 integration, then T-09 independent review/Manager verification.
6. After accepted/integrated #151 + #156, release/complete MFM-09, then MFM-10.
7. Once MFM-10 returns `SPECIES GUARD QUALIFIED`, freshly repin/complete PARITY-09; MFM-11 may proceed on the accepted lineage as ownership/Unity serialization permits.
8. Complete MFM-12 after its accepted dependencies and applicable Rack/parity/S1-C/S1-D lineages are present.
9. Assemble one exact candidate containing verified Rack V2, final parity, accepted S1-C/S1-D and MFM-12; run Tier-3 full integrated Scenario One qualification.
10. User personally playtests the same qualified Scenario One candidate.
11. Only after explicit user authorisation, create the fresh post-parity/full-loop Windows candidate.
12. Independent/native Windows technical smoke, then beginner external testing of the complete Scenario One.

The live execution order and machine lock are controlled by `Docs/Project/coordination/active-tasks.md` and Manager release, not by this numbered list alone.

## Completion checks

Before the first external Scenario One demo:

- the player can start from the initial forest, assess it, make an intervention, advance time, review consequences, make second and later interventions, adapt, repeat and reach scenario completion;
- Sitka spruce, Oak and Beech have comparable modelling depth with evidence quality labelled honestly;
- pure-Sitka protected arithmetic and anchors remain exact where required by D-061 and the parity spec;
- Oak and Beech do not silently inherit materially inappropriate Sitka-specific assumptions;
- mixed density uses the accepted ordinal species-aware growing-space architecture with no DEC, DMC or mixture-productivity bonus;
- Oak/Beech timber/economy follows the accepted parity evidence and does not fabricate form/site precision;
- Rack V2 uses Stand Map planning for Enlarged80, preserves compatibility and provides the approved physical entrance-marking behaviour;
- Multi-Scale Forestry Management V1 preserves player judgement and Work Plan commitment semantics;
- S1-C/S1-D history, advisory state and repeated-intervention behaviour are coherent across multiple cycles;
- malformed/ambiguous save data required by approved hardening tasks is rejected before mutation rather than silently repaired;
- frozen Reference Future v1 remains unchanged;
- full integrated qualification is green before a release candidate is considered;
- no Windows build occurs before the user's personal playtest and explicit authorisation.

## Compatibility and evidence constraints

- Preserve Legacy40 compatibility where the governing task/spec requires it.
- Preserve frozen Reference Future v1 bytes/semantics; do not resize, regenerate, migrate or reinterpret it.
- Preserve unrelated dirty work; one writer per owned subsystem/file set.
- Do not weaken verification merely to obtain a green result.
- Distinguish IMPLEMENTED, REVIEWED, INTEGRATED, VERIFIED and ACCEPTED.
- Use the authoritative evidence classes defined by the approved parity/evidence work. Game abstractions and gameplay calibrations must not be presented as measured Irish/UK forestry practice.
- Research guidance becomes a mechanic only when accepted by Decision Log/spec.

## Build candidate policy

Historical B06 and other pre-parity/pre-full-loop builds are engineering evidence only, not external-demo candidates. The eventual external-demo Windows candidate must be created fresh from the qualified complete-loop lineage after the user playtest/authorisation gate.

Player/native-Windows text, input and performance remain unqualified until their explicit gates run. Synthetic Editor input evidence does not substitute for native Windows smoke.

## Approved specs currently governing milestone work

- `specs/scenario-one-stand-map-headland-teaching-alignment-v1/` — **D-072** approved bounded **full Stand Map** physical V2 headland display then teaching figure; **independent spec review and Manager source-start gate still pending**. The previously approved Objective guidance specification remains authoritative for cue/focus/diagram rubric except the overridden map-fix ordering.

- `specs/scenario-one-objective-1-rack-planning-field-marking-v2/` — Rack V2 / D-064.
- `specs/scenario-one-three-species-parity-p0/` — three-species parity / D-059, D-061, D-062.
- `specs/scenario-one-review-history-v1/` — S1-C review/history.
- `specs/scenario-one-repeated-interventions-v1/` — S1-D repeated interventions.
- `specs/multiscale-forestry-management-v1/` — MFM V1 / D-065.

Only APPROVED / IMPLEMENTING / VERIFYING / VERIFIED specs authorise implementation. DRAFT/SUPERSEDED specs do not.

## Explicit exclusions

No Scenario Two implementation, sandbox, multi-scenario product expansion, unapproved yield equations, mixture-productivity bonus, stocking reduction, Reference Future modification, API/pay-as-you-go enablement, or unauthorised Windows build is part of this milestone. Deferred systems do not become scope merely because underlying infrastructure exists.

## Live coordination

`Docs/Project/coordination/active-tasks.md` is the live ownership/lock authority outside the context snapshot. Workers must refresh it and their task claim before substantial edits and before acquiring the machine-wide Unity lock. GitHub state alone does not prove local cleanliness or Unity/runtime state.
