CCF project context — verified 2026-11-19 bundle

ProjectContext/mirrors/ has the 12 stamped replacement Markdown mirrors. ProjectContext/context-manifest.json has SHA-256 checksums. Replace only the already-existing permanent Drive mirror files in place, verify matching hashes, then update manifest LAST.
ProjectContext/chatgpt-project-instructions.md and claude-project-instructions.md are generated Project attachment replacements.
chatgpt-compact-instructions-proposed.md is a draft for the ChatGPT project field; compare the existing field before replacing.
GitHub source handoff: https://github.com/jermur788/CCF/tree/b559519f8af5f2cf8f4625f989a800402f2dcd0c/Docs/Handoffs/ProjectContext-20261119
Issue #832 is not closed by downloading. No Drive files or project settings have been changed by this download.
